<div class="container">
	<div class="col-md-12">
		<?php echo html_entity_decode($meta['about']) ?>
	</div>
</div>